"""Simple tool wrapper around VectorDBQA chain."""
