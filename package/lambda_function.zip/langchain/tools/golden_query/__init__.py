"""Golden API toolkit."""


from langchain.tools.golden_query.tool import GoldenQueryRun

__all__ = [
    "GoldenQueryRun",
]
