"""Google Cloud Tools."""

from langchain.tools.google_cloud.texttospeech import GoogleCloudTextToSpeechTool

__all__ = ["GoogleCloudTextToSpeechTool"]
